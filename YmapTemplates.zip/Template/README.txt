1. Place all .Ymap files into "stream" 
2. Dont touch anything else 


---PersonInfo---
-Aidan
-Owner Of CSRP
-Discord: https://discord.gg/CYrxKYkwVd