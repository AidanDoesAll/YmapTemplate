resource_manifest_version '1.0.0'

this_is_a_map 'yes'


author 'Aidan'
description '[Version 1.0.0] Owner of Cyberstate Roleplay Discord:https://discord.gg/CYrxKYkwVd'